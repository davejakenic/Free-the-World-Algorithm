#ifndef HASH_HPP
#define HASH_HPP

#include <string>

std::string hash(std::string const& input);

#endif